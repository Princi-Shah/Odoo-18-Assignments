# -*- coding: utf-8 -*-
import json
from odoo import api, fields, models

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    approval_required = fields.Boolean(default=False)
    send_for_approval = fields.Boolean(default=True)
    approve_visible = fields.Boolean(default=False)
    state = fields.Selection(
        selection_add=[
            ("draft_quote", "Revised Quotation"),
            ("draft", "Quotation"),
            ("sent", "Quotation Sent"),
            ("revised", "Revised Order"),
            ("sale", "Sale Order"),
            ("pending_approval", "Pending Approval"),
            ("cancel", "Cancelled"),
        ], string="Status", readonly=True, copy=False, index=True, tracking=True, default="draft")
    approved_by = fields.Many2one(comodel_name='res.users', string="Approval By", readonly=True, copy=False)
    approved_date = fields.Datetime(string="Approved Date", readonly=True, copy=False)

    def action_send_for_approval(self):
        for record in self:
            record.state = 'pending_approval'
        records_to_send_mail_for = self.search([('approval_required', '=', True)])
        if records_to_send_mail_for:
            for data in records_to_send_mail_for:
                try:
                    template_id = self.env.ref('princishah_27102025.email_order_approval')
                    template_id.send_mail(data.id, force_send=True)
                except Exception as e:
                    print(f"Error sending mail: {e}")
                self.write({'approve_visible': True})
        else:
            print("No approval criteria to send mail.")

    def action_approve_button(self):
        for record in self:
            record.state = 'sale'
            self.message_post(
                body=f"Approver Name: {self.user_id.name},"
                     f"  Time Of Approval: {fields.Datetime.now().strftime('%H:%M')}",
                message_type='comment',
                subtype_xmlid='mail.mt_note'
            )
            self.write({'approved_by': self.user_id.id, 'approved_date': fields.Datetime.now()})
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }

    @api.model_create_multi
    def create(self, vals_list):
        orders = super().create(vals_list)

        param_val = self.env["ir.config_parameter"].sudo().get_param("princishah_27102025.manager_approvals")
        approval_ids = json.loads(param_val) if param_val else []
        approvals = self.env["sale.manager.approval"].browse(approval_ids)

        for order in orders:
            order._check_and_flag_approval(approvals)

        return orders


    def write(self, vals):
        res = super().write(vals)

        if self.env.context.get("skip_approval_check"):
            return res

        param_val = self.env["ir.config_parameter"].sudo().get_param("princishah_27102025.manager_approvals")
        approval_ids = json.loads(param_val) if param_val else []
        approvals = self.env["sale.manager.approval"].browse(approval_ids)

        for order in self:
            order._check_and_flag_approval(approvals)

        return res

    def _check_and_flag_approval(self, approvals):
        if not approvals:
            return

        approvals_sorted = approvals.sorted(key=lambda a: a.approval_threshold)

        applicable_manager = None
        for manager in approvals_sorted:
            if self.amount_total <= manager.approval_threshold:
                applicable_manager = manager
                break

        if not applicable_manager:
            applicable_manager = approvals_sorted[-1]

        if self.amount_total < approvals_sorted[0].approval_threshold:
            self.with_context(skip_approval_check=True).write({
                "approval_required": False,
                "send_for_approval": True,
                "approve_visible": False,
            })
        else:
            self.with_context(skip_approval_check=True).write({
                "approval_required": True,
                "send_for_approval": False,
                "approve_visible": True,
            })

            self.message_post(
                body=f"Approval required. Assigned approver: {applicable_manager.user_id.name}. "
                     f"Threshold: {applicable_manager.approval_threshold}. "
                     f"Order total: {self.amount_total}",
                message_type="comment",
            )