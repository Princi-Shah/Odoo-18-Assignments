# - * - coding: utf - 8 -*-
from odoo import api, fields, models
import json

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    manager_approvals = fields.Many2many(comodel_name='sale.manager.approval',
                                         string='Manager Approvals')

    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        ICPSudo = self.env['ir.config_parameter'].sudo()

        manager_approvals_str = ICPSudo.get_param('princishah_27102025.manager_approvals')
        if manager_approvals_str:
            manager_approvals_ids = json.loads(manager_approvals_str)
            res.update(
                manager_approvals=[(6, 0, manager_approvals_ids)]
            )
        return res

    def set_values(self):
        super(ResConfigSettings, self).set_values()
        ICPSudo = self.env['ir.config_parameter'].sudo()
        ICPSudo.set_param('princishah_27102025.manager_approvals', json.dumps(self.manager_approvals.ids))

