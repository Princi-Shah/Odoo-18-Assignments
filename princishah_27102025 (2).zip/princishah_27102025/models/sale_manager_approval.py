# - * - coding: utf - 8 -*-
from odoo import api, fields, models
from odoo.exceptions import ValidationError

class SaleManagerApproval(models.Model):
    _name = 'sale.manager.approval'
    _rec_name = 'user_id'

    user_id = fields.Many2one(comodel_name='res.users', string='User', required=True)
    approval_threshold = fields.Float(string='Approval Threshold Amount', required=True)
    currency_id = fields.Many2one(comodel_name='res.currency', string='Currency',
                                  compute='_compute_currency_id')
    display_name = fields.Char(string='Display Name', compute='_compute_display_name',
                               store=True)

    _sql_constraints = [('unique_approval_threshold', 'unique (approval_threshold)',
                         'Threshold Amount is already configured.')]

    @api.depends('user_id.name', 'approval_threshold', 'currency_id')
    def _compute_display_name(self):
        for record in self:
            record.display_name = (
                f"{record.user_id.name} - {record.currency_id.symbol} "
                f"[{record.approval_threshold}]")

    @api.depends_context('allowed_company_ids')
    def _compute_currency_id(self):
        self.currency_id = self.env.company.currency_id

    @api.model
    def _run_sale_order_approval_reminder(self):
        pending_order = self.env['sale.order'].search([('state', '=' , 'pending_approval')])
        if pending_order:
            for records in pending_order:
                try:
                    template_id = self.env.ref('princishah_27102025.email_order_approval')
                    template_id.send_mail(records.id, force_send=True)
                except Exception as e:
                    print(f"Error sending mail: {e}")
        else:
            print("No Reminder Mails.")
