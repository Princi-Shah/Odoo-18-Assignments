# - * - coding: utf - 8 -*-

from . import sale_order
from . import sale_manager_approval
from . import product_template
from . import res_config_settings