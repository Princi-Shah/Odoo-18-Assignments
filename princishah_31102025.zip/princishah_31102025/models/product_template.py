# - * - coding: utf - 8 -*-
from odoo import models, fields, api

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    review_ids = fields.One2many('product.review', 'product_id', string='Reviews')
    reviews_count = fields.Integer(string='Number of Reviews',
                                   compute='_compute_reviews_count')

    def _compute_reviews_count(self):
        for product in self:
            product.reviews_count = len(product.review_ids.filtered(
                lambda r: r.state == 'approved'))
