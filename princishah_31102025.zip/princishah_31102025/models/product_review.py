# -*- coding: utf-8 -*-
from odoo import models, fields, api

class ProductReview(models.Model):
    _name = 'product.review'
    _description = 'Product Review'
    _order = 'create_date desc'

    product_id = fields.Many2one('product.template', string='Product', required=True,
                                 ondelete='cascade')
    user_id = fields.Many2one('res.users', string='Reviewer', required=True,
                              default=lambda self: self.env.user.id)
    rating = fields.Selection([
        ('1', '1 Star'),
        ('2', '2 Stars'),
        ('3', '3 Stars'),
        ('4', '4 Stars'),
        ('5', '5 Stars'),
    ], string='Rating', required=True)
    summary = fields.Char(string='Summary', required=True)
    review_text = fields.Text(string='Review')
    state = fields.Selection([
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ], string='Status', default='pending', required=True)
