from odoo import http
from odoo.http import request
from odoo.addons.website.controllers.main import Website

class ProductReviewController(http.Controller):
    @http.route('/shop/product/submit_review', type='json', auth='user',
                methods=['POST'], website=True)
    def submit_product_review(self, product_id, rating, summary, review_text):
        product = request.env['product.template'].sudo().search([('id', '=', product_id)])

        if not product:
            return {'error': 'Product not found.'}

        if request.env.user == request.env.ref('base.public_user'):
            return {'error': 'You must be logged in to submit a review.'}

        review_vals = {
            'product_id': product_id,
            'user_id': request.env.user.id,
            'rating': rating,
            'summary': summary,
            'review_text': review_text,
            'state': 'pending',
        }

        try:
            request.env['product.review'].sudo().create(review_vals)
            return {'success': 'Your review has been submitted successfully and is awaiting approval.'}
        except Exception as e:
            return {'error': str(e)}

