odoo.define('product_reviews.review', function (require) {
    'use strict';

    var core = require('web.core');
    var rpc = require('web.rpc');
    var _t = core._t;

    $(document).ready(function () {
        $('#review_form').on('submit', function (event) {
            event.preventDefault();

            var form = $(this);
            var data = {
                product_id: form.find('input[name="product_id"]').val(),
                rating: form.find('select[name="rating"]').val(),
                summary: form.find('input[name="summary"]').val(),
                review_text: form.find('textarea[name="review_text"]').val(),
            };
            var messageArea = $('#review_message');
            messageArea.empty();

            rpc.query({
                route: "/shop/product/submit_review",
                params: data,
            }).then(function (result) {
                if (result.success) {
                    messageArea.html('<div class="alert alert-success">' + result.success + '</div>');
                    form[0].reset();
                } else if (result.error) {
                    messageArea.html('<div class="alert alert-danger">' + result.error + '</div>');
                }
            }).catch(function (error) {
                messageArea.html('<div class="alert alert-danger">' + _t("An error occurred.") + '</div>');
            });
        });
    });
});
