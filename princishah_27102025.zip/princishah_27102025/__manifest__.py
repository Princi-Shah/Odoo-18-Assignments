# - * - coding: utf - 8 -*-

{
    'name': 'princishah_27102025',
    'version': '18.0.1.0.0',
    'author': 'Your Name',
    'category': 'Library',
    'website': 'https://www.aktivsoftware.com',
    'description': """Sale Order Manager Approval""",
    'depends': ['base','sale_management','stock','sales_team'],
    'data': [
        'security/ir.model.access.csv',
        'views/sale_manager_approval_views.xml',
        'views/res_config_settings_views.xml',
        'views/sale_order_inherited_views.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
}


