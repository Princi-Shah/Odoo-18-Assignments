# - * - coding: utf - 8 -*-

from . import sale_order
from . import sale_manager_approval
from . import res_config_settings
