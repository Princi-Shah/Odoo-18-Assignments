# -*- coding: utf-8 -*-
from odoo import api, fields, models


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    approval_required = fields.Boolean(default=False)
    send_for_approval = fields.Boolean(default=True)
    approve_visible = fields.Boolean(default=False)
    state = fields.Selection(
        selection_add=[
            ("draft_quote", "Revised Quotation"),
            ("draft", "Quotation"),
            ("sent", "Quotation Sent"),
            ("revised", "Revised Order"),
            ("sale", "Sale Order"),
            ("pending_approval", "Pending Approval"),
            ("cancel", "Cancelled"),
        ],
        string="Status",
        readonly=True,
        copy=False,
        index=True,
        tracking=True,
        default="draft",
    )

    def action_send_for_approval(self):
        for record in self:
            record.state = 'pending_approval'
        records_to_send_mail_for = self.search([('approval_required', '=', True)])
        if records_to_send_mail_for:
            for data in records_to_send_mail_for:
                try:
                    template_id = self.env.ref('princishah_27102025.email_order_approval')
                    template_id.send_mail(data.id, force_send=True)
                except Exception as e:
                    print(f"Error sending mail: {e}")
                self.write({'approve_visible': True})
        else:
            print("No approval criteria to send mail.")

    def action_approve_button(self):
        for record in self:
            record.state = 'sale'
            self.message_post(
                body=f"Approver Name: {self.user_id.name},"
                     f"  Time Of Approval: {fields.Datetime.now().strftime("%H:%M")}",
                message_type='comment',
                subtype_xmlid='mail.mt_note'
            )
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }

    @api.model_create_multi
    def create(self, values):
        res = super(SaleOrder, self).create(values)
        data = self.env["ir.config_parameter"].sudo().get_param("princishah_27102025.manager_approvals")
        id_list = []
        if data:
            clean_data = data.strip('[]')
            id_list = [int(i) for i in clean_data.split(',')]
        records = self.env['sale.manager.approval'].browse(id_list)
        for sale_order_record, item in zip(res, values):
            amount_total = 0.0
            if 'order_line' in item and item['order_line']:
                for line in item['order_line']:
                    if isinstance(line, (list, tuple)) and len(line) == 3 and line[0] == 0:
                        line_values = line[2]
                        if 'price_unit' in line_values:
                            amount_total += line_values['price_unit']
            approval_needed = any(amount_total > record.approval_threshold for record in records)
            sale_order_record.write({'approval_required': approval_needed,'send_for_approval': False})
        return res

    def write(self, values):
        res = super(SaleOrder, self).write(values)
        if self.env.context.get('skip_approval_check'):
            return res
        data = self.env['ir.config_parameter'].sudo().get_param(
            'princishah_27102025.manager_approvals')
        id_list = []
        if data:
            clean_data = data.strip('[]')
            id_list = [int(i) for i in clean_data.split(',')]
        records = self.env['sale.manager.approval'].browse(id_list)
        for sale_order_record in self:
            amount_total = 0.0
            if 'order_line' in values and values['order_line']:
                for line in sale_order_record.order_line:
                    amount_total += line.price_unit * line.product_uom_qty
            else:
                amount_total = sale_order_record.amount_total
            approval_needed = any(amount_total > record.approval_threshold for record in records)
            sale_order_record.with_context(skip_approval_check=True).write(
                {'approval_required': approval_needed, 'send_for_approval': False})
        return res
