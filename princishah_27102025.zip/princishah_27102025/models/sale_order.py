# -*- coding: utf-8 -*-
import json
from odoo import api, fields, models
from odoo.exceptions import ValidationError


class SaleOrder(models.Model):
    _inherit = "sale.order"

    approval_required = fields.Boolean(default=False)
    send_for_approval = fields.Boolean(default=False)
    approve_visible = fields.Boolean(default=False)
    state = fields.Selection(
        selection_add=[
            ("draft_quote", "Revised Quotation"),
            ("draft", "Quotation"),
            ("sent", "Quotation Sent"),
            ("revised", "Revised Order"),
            ("sale", "Sale Order"),
            ("pending_approval", "Pending Approval"),
            ("cancel", "Cancelled"),
        ],
        string="Status", readonly=True, copy=False,
        index=True, tracking=True, default="draft")
    approved_by = fields.Many2one(comodel_name='res.users', string="Approval By",
                                  readonly=True, copy=False)
    approved_date = fields.Datetime(string="Approved Date", readonly=True, copy=False)
    applicable_manager_id = fields.Many2one(comodel_name='res.users',
                                            string="Applicable Manager",readonly=True,
                                            compute='_compute_applicable_manager',
                                            store=True)

    @api.depends('amount_total')
    def _compute_applicable_manager(self):
        data = self.env['ir.config_parameter'].sudo().get_param(
            'princishah_27102025.manager_approvals')
        id_list = []
        if data:
            try:
                clean_data = data.strip('[]')
                if clean_data:
                    id_list = [int(i) for i in clean_data.split(',')]
            except ValueError:
                id_list = []

        approvals_records = self.env['sale.manager.approval'].browse(id_list)
        approvals_sorted = approvals_records.sorted(key=lambda a: a.approval_threshold)

        for record in self:
            applicable_manager = None
            if not approvals_sorted:
                record.applicable_manager_id = False
                continue

            for manager_rule in approvals_sorted:
                if record.amount_total <= manager_rule.approval_threshold:
                    applicable_manager = manager_rule.user_id
                    break

            if not applicable_manager:
                applicable_manager = approvals_sorted[-1].user_id
            record.applicable_manager_id = applicable_manager.id


    def action_send_for_approval(self):
        for record in self:
            record.state = 'pending_approval'
        records_to_send_mail_for = self.search([('approval_required', '=', True)])

        if records_to_send_mail_for:
            for data in records_to_send_mail_for:
                try:
                    template_id = self.env.ref(
                        'princishah_27102025.email_order_approval')
                    template_id.send_mail(data.id, force_send=True)
                except Exception as e:
                    print(f"Error sending mail: {e}")


    @api.model_create_multi
    def create(self, vals_list):
        orders = super().create(vals_list)

        param_val = self.env["ir.config_parameter"].sudo().get_param(
            "princishah_27102025.manager_approvals")
        approval_ids = json.loads(param_val) if param_val else []
        approvals = self.env["sale.manager.approval"].browse(approval_ids)

        for order in orders:
            order._check_and_flag_approvals(approvals)
        return orders


    def write(self, vals):
        previous_states = {order.id: order.state for order in self}
        previous_amounts = {order.id: order.amount_total for order in self}
        print("previous_states: ", previous_states)
        print("previous_amounts: ", previous_amounts)

        res = super().write(vals)

        if self.env.context.get("skip_approval_check"):
            return res

        param_val = self.env["ir.config_parameter"].sudo().get_param(
            "princishah_27102025.manager_approvals")
        approval_ids = json.loads(param_val) if param_val else []
        approvals = self.env["sale.manager.approval"].browse(approval_ids)

        for order in self:
            was_sale_state = previous_states.get(order.id) == 'sale'
            is_amount_changed = order.amount_total != previous_amounts.get(order.id)
            print("was_sale_state: ", was_sale_state)
            print("is_amount_changed: ", is_amount_changed)
            if was_sale_state and is_amount_changed:
                order.with_context(skip_approval_check=True)._check_and_flag_approvals(
                    approvals)
                if order.approval_required:
                    order.with_context(skip_approval_check=True).write(
                        {'state': 'revised',
                         'approved_by': False,
                         'approved_date': False, })
            else:
                order._check_and_flag_approvals(approvals)
        return res


    def _check_and_flag_approvals(self, approvals):
        if not approvals:
            return

        approvals_sorted = approvals.sorted(key=lambda a: a.approval_threshold)
        applicable_manager = self.applicable_manager_id

        if self.amount_total <= approvals_sorted[0].approval_threshold:
            self.with_context(skip_approval_check=True).write(
                {'send_for_approval': False,
                 'approval_required': False,
                 'approve_visible': True})
        else:
            self.with_context(skip_approval_check=True).write(
                {'send_for_approval': True,
                 'approval_required': True,
                 'approve_visible': False})
        self.message_post(
            body=f"Approval required. Assigned approver: {applicable_manager.name}. "
                 f"Order total: {self.amount_total}",
            message_type="comment",
        )
        if self.state == "pending_approval":
            self.with_context(skip_approval_check=True).write(
                {'send_for_approval': False,
                 'approval_required': True,
                 'approve_visible': True})


    def action_approve_button(self):
        is_approver = self.applicable_manager_id.id == self.env.user.id
        if is_approver:
            for record in self:
                record.state = 'sale'
                record.message_post(
                    body=f"Approver Name: {self.applicable_manager_id.name},"
                         f"  Time Of Approval: {
                         fields.Datetime.now().strftime('%H:%M')}",
                    message_type='comment',
                    subtype_xmlid='mail.mt_note'
                )

                record.write({'approved_by': self.env.user.id,
                              'approved_date': fields.Datetime.now(),
                              'approval_required': False,
                              'approve_visible': False,
                              'send_for_approval': False,
                              })

            return {
                'type': 'ir.actions.client',
                'tag': 'reload',
            }
        else:
            raise ValidationError(f"You are not the authorized approver. "
                                  f"The designated approver is:  "
                                  f"{self.applicable_manager_id.name}")
