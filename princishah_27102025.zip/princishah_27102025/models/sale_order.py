# -*- coding: utf-8 -*-

from odoo import api, fields, models

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    approval_required = fields.Boolean(default=False)
    state = fields.Selection(
        selection_add=[
            ("draft_quote", "Revised Quotation"),
            ("draft", "Quotation"),
            ("sent", "Quotation Sent"),
            ("revised", "Revised Order"),
            ("sale", "Sale Order"),
            ("pending_approval", "Pending Approval"),
            ("cancel", "Cancelled"),
        ],
        string="Status",
        readonly=True,
        copy=False,
        index=True,
        tracking=True,
        default="draft",
    )

    def action_send_for_approval(self):
        for record in self:
            record.state = 'pending_approval'

    @api.model_create_multi
    def create(self, values):
        for item in values:
            amount_total = 0.0
            if 'order_line' in item and item['order_line']:
                for line in item['order_line']:
                    if isinstance(line, (list, tuple)) and len(line) == 3 and line[0] == 0:
                        line_values = line[2]
                        if 'price_unit' in line_values:
                            price_unit_value = line_values['price_unit']
                            amount_total += price_unit_value
            print("total amount", amount_total)
            data = self.env["ir.config_parameter"].sudo().get_param("princishah_27102025.manager_approvals")
            # data.filtered(lambda vals: vals.amount_total > vals.approval_threshold)
            print("data",data)
            records = self.env['sale.manager.approval'].browse()
            print("records",records)

        return super(SaleOrder, self).create(values)
