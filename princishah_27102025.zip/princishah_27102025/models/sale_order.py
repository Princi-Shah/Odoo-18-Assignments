# # -*- coding: utf-8 -*-
# from odoo import api, fields, models
#
#
# class SaleOrder(models.Model):
#     _inherit = 'sale.order'
#
#     approval_required = fields.Boolean(default=False)
#     send_for_approval = fields.Boolean(default=True)
#     approve_visible = fields.Boolean(default=False)
#     state = fields.Selection(
#         selection_add=[
#             ("draft_quote", "Revised Quotation"),
#             ("draft", "Quotation"),
#             ("sent", "Quotation Sent"),
#             ("revised", "Revised Order"),
#             ("sale", "Sale Order"),
#             ("pending_approval", "Pending Approval"),
#             ("cancel", "Cancelled"),
#         ], string="Status", readonly=True, copy=False, index=True, tracking=True, default="draft")
#     approved_by = fields.Many2one(comodel_name='res.users', string="Approval By", readonly=True, copy=False)
#     approved_date = fields.Datetime(string="Approved Date", readonly=True, copy=False)
#
#     previous_amount_total = fields.Float(compute='_compute_previous_amount_total', store=True, readonly=False)
#
#     @api.depends('amount_total')
#     def _compute_previous_amount_total(self):
#         for rec in self:
#             if not rec.id:
#                 rec.previous_amount_total = rec.amount_total
#
#     def action_send_for_approval(self):
#         for record in self:
#             record.state = 'pending_approval'
#         records_to_send_mail_for = self.search([('approval_required', '=', True)])
#         if records_to_send_mail_for:
#             for data in records_to_send_mail_for:
#                 try:
#                     template_id = self.env.ref('princishah_27102025.email_order_approval')
#                     template_id.send_mail(data.id, force_send=True)
#                 except Exception as e:
#                     print(f"Error sending mail: {e}")
#                 self.write({'approve_visible': True})
#         else:
#             print("No approval criteria to send mail.")
#
#     def action_approve_button(self):
#         for record in self:
#             record.state = 'sale'
#             self.message_post(
#                 body=f"Approver Name: {self.user_id.name},"
#                      f"  Time Of Approval: {fields.Datetime.now().strftime("%H:%M")}",
#                 message_type='comment',
#                 subtype_xmlid='mail.mt_note'
#             )
#             self.write({'approved_by': self.user_id.name, 'approved_date': fields.Datetime.now()})
#         return {
#             'type': 'ir.actions.client',
#             'tag': 'reload',
#         }
#
#     # @api.model_create_multi
#     # def create(self, values):
#     #     res = super(SaleOrder, self).create(values)
#     #     data = self.env["ir.config_parameter"].sudo().get_param("princishah_27102025.manager_approvals")
#     #     id_list = []
#     #     if data:
#     #         clean_data = data.strip('[]')
#     #         id_list = [int(i) for i in clean_data.split(',')]
#     #         if id_list:
#     #             records = self.env['sale.manager.approval'].browse(id_list)
#     #             threshold_amounts = [record.approval_threshold for record in records if record.approval_threshold]
#     #             print("threshold_amounts: ", threshold_amounts) #[1000.0, 2000.0, 3000.0]
#     #     print("======>", records)
#     #     for sale_order_record, item in zip(res, values):
#     #         if 'order_line' in item and item['order_line']:
#     #             for line in item['order_line']:
#     #                 if isinstance(line, (list, tuple)) and len(line) == 3 and line[0] == 0:
#     #                     line_values = line[2]
#     #                     if 'price_unit' in line_values:
#     #                         self.amount_total += line_values['price_unit']
#     #                         print("amount_total", self.amount_total)
#     #
#     #         approval_needed = any(self.amount_total > record.approval_threshold for record in records)
#     #         if approval_needed:
#     #             sale_order_record.write({'approval_required': approval_needed, 'send_for_approval': False})
#     #     return res
#
#     @api.model_create_multi
#     def create(self, values_list):
#         res = super(SaleOrder, self).create(values_list)
#         data = self.env['ir.config_parameter'].sudo().get_param('princishah_27102025.manager_approvals')
#         id_list = []
#         if data:
#             clean_data = data.strip('[]')
#             if clean_data:
#                 id_list = [int(i) for i in clean_data.split(',')]
#
#         records = self.env['sale.manager.approval'].browse(id_list) if id_list else self.env['sale.manager.approval']
#         print("records", records)
#         threshold_amounts = [record.approval_threshold for record in records if record.approval_threshold]
#         print("threshold_amounts", threshold_amounts)
#         # data_threshold_amount_sorted = [lambda x: x.threshold_amounts >= ]
#         # print("threshold_amounts", threshold_amounts)
#         # print("threshold_amounts", data_threshold_amount_sorted)
#         for sale_order_record, item_values in zip(res, values_list):
#             calculated_amount_total = 0.0
#             if 'order_line' in item_values and item_values['order_line']:
#                 for line_command in item_values['order_line']:
#                     if isinstance(line_command, (list, tuple)) and len(line_command) == 3 and line_command[0] == 0:
#                         line_values = line_command[2]
#                         if 'price_unit' in line_values and 'product_uom_qty' in line_values:
#                             calculated_amount_total += line_values['price_unit'] * line_values['product_uom_qty']
#                 print("calculated amount total", calculated_amount_total)
#                 for vals in threshold_amounts:
#                     if calculated_amount_total >= vals:
#                         if True:
#
#                     else:
#                         print("not found")
#
#             approval_needed = any(
#                 calculated_amount_total > record.approval_threshold for record in records if record.approval_threshold)
#
#             if approval_needed:
#                 sale_order_record.write({
#                     'approval_required': approval_needed,
#                     'send_for_approval': False
#                 })
#         return res
#
#     def write(self, values):
#         res = super(SaleOrder, self).write(values)
#         if self.env.context.get('skip_approval_check'):
#             return res
#         data = self.env['ir.config_parameter'].sudo().get_param(
#             'princishah_27102025.manager_approvals')
#
#         id_list = []
#         if data:
#             clean_data = data.strip('[]')
#             id_list = [int(i) for i in clean_data.split(',')]
#
#         approval_records = self.env['sale.manager.approval'].browse(id_list)
#
#         for sale_order_record in self:
#             current_total_amount = sale_order_record.amount_total
#
#             if 'order_line' in values and values['order_line']:
#                 pass
#             approval_needed = any(current_total_amount > record.approval_threshold for record in approval_records)
#             if approval_needed:
#                 sale_order_record.with_context(skip_approval_check=True).write(
#                     {'approval_required': approval_needed, 'send_for_approval': False})
#
#         return res
#
# ----------------------------------------

# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    approval_required = fields.Boolean(default=False)
    send_for_approval = fields.Boolean(default=True)
    approve_visible = fields.Boolean(default=False)
    state = fields.Selection(
        selection_add=[
            ("draft_quote", "Revised Quotation"),
            ("draft", "Quotation"),
            ("sent", "Quotation Sent"),
            ("revised", "Revised Order"),
            ("sale", "Sale Order"),
            ("pending_approval", "Pending Approval"),
            ("cancel", "Cancelled"),
        ], string="Status", readonly=True, copy=False, index=True, tracking=True, default="draft")
    approved_by = fields.Many2one(comodel_name='res.users', string="Approval By", readonly=True, copy=False)
    approved_date = fields.Datetime(string="Approved Date", readonly=True, copy=False)
    previous_amount_total = fields.Float(compute='_compute_previous_amount_total', store=True, readonly=False)

    @api.depends('amount_total')
    def _compute_previous_amount_total(self):
        for rec in self:
            # We don't want this compute to update the stored value on every change,
            # so we only set it on a new record. The write method handles state-based updates.
            if not rec.id:
                rec.previous_amount_total = rec.amount_total

    def action_send_for_approval(self):
        for record in self:
            record.state = 'pending_approval'
            record.approve_visible = True
            if record.approval_required:
                try:
                    template_id = self.env.ref('princishah_27102025.email_order_approval')
                    template_id.send_mail(record.id, force_send=True)
                except Exception as e:
                    print(f"Error sending mail: {e}")
            else:
                print("No approval criteria to send mail for this record.")

    def action_approve_button(self):
        for record in self:
            record.state = 'sale'
            record.message_post(
                body=f"Approver Name: {self.env.user.name},"
                     f"  Time Of Approval: {fields.Datetime.now().strftime('%H:%M')}",
                message_type='comment',
                subtype_xmlid='mail.mt_note'
            )
            record.approved_by = self.env.user.name  # Use the user's name directly as per your variable.
            record.approved_date = fields.Datetime.now()
            record.approval_required = False
            record.send_for_approval = True
            record.approve_visible = False
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }

    @api.model_create_multi
    def create(self, values_list):
        records = super(SaleOrder, self).create(values_list)
        for record in records:
            record._check_and_update_approval()
        return records

    def _check_and_update_approval(self):
        """
        Helper method to determine if approval is required based on the total amount.
        Returns True if approval is needed, False otherwise.
        """
        self.ensure_one()
        data = self.env['ir.config_parameter'].sudo().get_param('princishah_27102025.manager_approvals')
        id_list = []
        if data:
            try:
                clean_data = data.strip('[]')
                if clean_data:
                    id_list = [int(i) for i in clean_data.split(',')]
            except ValueError:
                id_list = []

        approval_records = self.env['sale.manager.approval'].browse(id_list) if id_list else self.env[
            'sale.manager.approval']

        if not approval_records:
            return False

        current_total = self.amount_total
        approval_needed = any(
            current_total > record.approval_threshold for record in approval_records if record.approval_threshold)

        if approval_needed and not self.approval_required:
            self.write({
                'approval_required': True,
                'send_for_approval': False,
            })
            # Transition state if not yet approved
            if self.state in ['draft', 'sent', 'revised', 'sale']:
                self.write({'state': 'pending_approval' if self.state != 'sale' else 'revised'})

        elif not approval_needed and self.approval_required:
            # If no longer needed, move back to draft, only if not yet sold
            if self.state in ['pending_approval', 'revised']:
                self.write({
                    'approval_required': False,
                    'send_for_approval': True,
                    'state': 'draft'
                })

        return approval_needed

    def write(self, values):
        # Store old amounts for comparison before the `super` call
        previous_amounts = {record.id: record.amount_total for record in self}

        # Call the parent write method to apply changes
        res = super(SaleOrder, self).write(values)

        # Skip this check if triggered from within the re-approval logic
        if self.env.context.get('skip_approval_check'):
            return res

        for record in self:
            is_amount_changed = 'amount_total' in values or 'order_line' in values
            is_was_approved = record.state == 'sale'

            if is_was_approved and (is_amount_changed or record.amount_total != previous_amounts.get(record.id)):
                # If amount changes on an approved order, check for re-approval
                if record._check_and_update_approval():
                    # Revert state and approval details for re-approval
                    record.with_context(skip_approval_check=True).write({
                        'state': 'revised',
                        'approved_by': False,
                        'approved_date': False,
                    })
        return res

